<div style='max-width:768px; margin:1rem auto; font-family:"Segoe UI", Tahoma, Geneva, Verdana, sans-serif; '>
  <p style='color:<?= $titleColor ?>; background-color:<?= $titleBackground ?>; padding:.25rem; margin:0; '>
    <strong><?= $titulek ?></strong>
  </p>
  <div style='color:<?= $textColor ?>; background-color:<?= $textBackground ?>; padding:.25rem; margin:0; '>
    <?= $text ?>
</div>
</div>