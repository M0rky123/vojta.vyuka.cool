<?php 
  // Načtení funkcí
  foreach( glob(__DIR__ . "/../funkce/*.php") as $funkce ) include $funkce ;
