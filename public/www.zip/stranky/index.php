<h2>Ahoj. Jsem <strong>Dobroš Nechvalný</strong>.</h2>

<p>
  Vzniknul jsem 19. 1. 2023 jako téma písemného testu z PGS pro 3.L.
</p>
<p>
  Tak asi tak...
</p>

<p>
  Vypočítal jsem to: <?= $vysledekVypoctu ?>
</p>

<?php // echo vypisPromennou("SERVER", $_SERVER) ?>