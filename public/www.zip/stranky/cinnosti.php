<h2>Co rád dělám</h2>

<p>Chtěl bych se s vámi podělit o to, co kdy rád dělám:</p>

<ul>
  <li>v pondělí mám rád nemít rád pondělí, ale <a href='https://www.youtube.com/watch?v=-Kobdb37Cwc'
      target='_blank'>zase ne takhle moc</a></li>
  <li>v úterý mám rád politovat <a href='https://www.youtube.com/watch?v=LJrFxnvcWhc' target='_blank'>Ronnie Van
      Zanta</a></li>
  <li>v středa mám rád když <a href='https://www.youtube.com/watch?v=0MawIv5pDFE' target='_blank'>je tak trochu
      jiná</a></li>
  <li>v čtvrtek mám rád <a href='https://www.youtube.com/watch?v=gfOKDB0ChQk' target='_blank'>si představovat co by
      kdyby</a></li>
  <li>v pátek mám rád že je <a href='https://www.youtube.com/watch?v=dnqxbdnzlhw' target='_blank'>konečně tady</a>
  </li>
  <li>v sobota mám rád když <a href='https://www.youtube.com/watch?v=NagnbRHdh-0' target='_blank'>je jak má být</a>
  </li>
  <li>v neděle mám rád že <a href='https://www.youtube.com/watch?v=-51-0Mx_n0w' target='_blank'>jsem zase o týden
      chytřejší</a></li>
</ul>