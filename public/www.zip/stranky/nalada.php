<h2>Kdybyste mě náhodou potkali, abyste nebyli překvapení...</h2>

<ul>
  <li>
    K snídani jsem si připálil vajíčka, takže jsem docela nevrlej.
  </li>
</ul>