<?php

$vysledekVypoctu = "No nazdar" ;